drop table Tren;

drop table Orase;

create table Tren (Numar_tren VARCHAR2(10),
                   Tip VARCHAR2(2));
                   
create table Orase (Oras VARCHAR2(36),
                    Numar_tren VARCHAR2(10),
                    Ora_sosire NUMBER(15),
                    Ora_plecare NUMBER(15),
                    Secunde_parcurse NUMBER(15),
                    Stationare VARCHAR2(1));

select * from tren;              


select * from orase where oras = 'Gala?i';       

SELECT o.Oras, o1.Oras, o.Numar_tren, o.Ora_sosire, o.Ora_plecare, o1.Ora_sosire, o1.Ora_plecare FROM Orase o
                JOIN Orase o1
                ON o.Numar_tren = o1.Numar_tren
                AND o.Oras= 'Suceava'
                AND o1.Oras= 'Pa?cani'
                AND o1.Ora_plecare = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340);

select tip as "1" from tren where numar_tren='1832';
              
SELECT o.Numar_tren as "1", o.Oras as "2", o1.Oras as "3" , o.Ora_plecare as "4" , o1.Ora_sosire as "5" FROM Orase o
                JOIN Orase o1
                ON o.Numar_tren = o1.Numar_tren
                AND o.Oras= 'Cluj Napoca'
                AND o1.Oras = 'Suceava'
                AND 
                ( (o1.Ora_Sosire = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340) AND o.Secunde_parcurse<o1.Secunde_parcurse)
                  OR
                  (o1.Ora_plecare = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340) AND o.Secunde_parcurse<o1.Secunde_parcurse)
                )
                ;
select * from Orase;
select * from Orase where Numar_tren='1003' order by Secunde_parcurse;


SELECT o.Oras, o1.Oras, o.Numar_tren, o.Ora_sosire, o.Ora_plecare, o1.Ora_sosire, o1.Ora_plecare FROM Orase o JOIN Orase o1 
                ON o.Numar_tren = o1.Numar_tren
                AND o.Oras = 'Predeal' 
                AND o1.Oras = 'Podu Olt'
                AND o1.Ora_sosire > o.Ora_plecare;

select * from orase where oras= 'Suceava';


SELECT * FROM Orase o
                JOIN Orase o1
                ON o.Numar_tren = o1.Numar_tren
                AND o.Oras= 'Cluj Napoca'
                AND o1.Oras = 'Suceava'
                AND 
                ( (o1.Ora_Sosire = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340) AND o.Secunde_parcurse<o1.Secunde_parcurse)
                  OR
                  (o1.Ora_plecare = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340) AND o.Secunde_parcurse<o1.Secunde_parcurse)
                )
                ;
