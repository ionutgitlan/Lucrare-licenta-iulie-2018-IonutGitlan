n=44

file = open (str(n)+'.txt', 'r',encoding='utf-8')
x = file.readlines ()
for p in range(0,len(x)-1):
    print ('insert into Trasee values (\'' + (x[p])[:-1] + '\', \'' + str(n) + '\', \'6:20, 6:35\', ' + str(p) + ');')
print('insert into Trasee values (\'' + x[len(x)-1] + '\', \'' + str(n) + '\', \'6:20, 6:35\', ' + str(len(x)-1) + ');')