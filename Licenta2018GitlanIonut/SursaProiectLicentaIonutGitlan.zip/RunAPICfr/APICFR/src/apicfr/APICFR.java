package apicfr;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

import org.json.*;

public class APICFR {

    public static String getDelay(String train) throws IOException {
        URL url = new URL("http://localhost:9090/train/" + train);
        //make connection
        URLConnection urlc = url.openConnection();
        //get result
        BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
        //creare fisier xml
        PrintWriter writer = new PrintWriter("info.xml", "UTF-8");
        String l = null;
        while ((l = br.readLine()) != null) {

            writer.println(l);
            return (l.subSequence(l.indexOf("Delay") + 8, l.indexOf("Destination") - 3)).toString();
            //System.out.println(l.subSequence(l.indexOf("LatestInfo") + 13, l.indexOf("LatestInfoTime") - 3));
        }
        br.close();
        writer.close();
        return "0";
    }
    
    public static String getLastStation(String train) throws IOException {
        URL url = new URL("http://localhost:9090/train/" + train);
        //make connection
        URLConnection urlc = url.openConnection();
        //get result
        BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
        //creare fisier xml
        PrintWriter writer = new PrintWriter("info.xml", "UTF-8");
        String l = null;
        while ((l = br.readLine()) != null) {

            writer.println(l);
            return (l.subSequence(l.indexOf("LatestInfo") + 13, l.indexOf("LatestInfoTime") - 24)).toString();
        }
        br.close();
        writer.close();
        return "0";
    }

    public static void main(String[] args) throws Exception {
        /* ProcessBuilder builder = new ProcessBuilder(
                "cmd.exe", "/c", "cd E:\\Facultate\\Licenta\\VERIF\\cfr-iris-scraper-master && node .");
        builder.redirectErrorStream(true);
        Process p = builder.start();*/
        /*ProcessBuilder builder = new ProcessBuilder();
        
        builder.command("cmd.exe", "E:", "cd E:\\Facultate\\Licenta\\VERIF\\cfr-iris-scraper-master", "node .");

        Process process = builder.start();*/
        //System.out.print(getDelay("1885"));
        System.out.print(getLastStation("1565"));
        /*int x = 1;
        while (x > 0) {
            getDelay();
            x--;
        }*/


        /*BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();
            if (line == null) { break; }
            System.out.println(line);
        }*/
    }

}
