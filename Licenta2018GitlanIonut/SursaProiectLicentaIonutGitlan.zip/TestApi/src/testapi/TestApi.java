package testapi;

import java.io.*;
import java.net.*;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import java.io.IOException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class TestApi {

    public static void callApi(String oras) throws IOException, ParserConfigurationException {
        URL url = new URL("https://maps.googleapis.com/maps/api/geocode/xml?address="
                + oras + "&language=ro&key=AIzaSyAtJJjRv6Zyv8irYPQJ34xHTvGVLl-NE9c");
        //make connection
        URLConnection urlc = url.openConnection();
        //get result
        BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
        //creare fisier xml
        PrintWriter writer = new PrintWriter(oras + ".xml", "UTF-8");
        String l = null;
        while ((l = br.readLine()) != null) {
            writer.println(l);
        }
        br.close();
        writer.close();
    }

    public static String getLat(String c) {

        try {
            File inputFile = new File(c);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("location");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    return eElement.getElementsByTagName("lat").item(0).getTextContent();
                }
            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
        return null;
    }

    public static String getLng(String c) {

        try {
            File inputFile = new File(c);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("location");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    return eElement.getElementsByTagName("lng").item(0).getTextContent();
                }
            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
        return null;
    }

    public static void callDistance(String lat1, String lng1, String lat2, String lng2, String mod) throws MalformedURLException, FileNotFoundException, UnsupportedEncodingException, IOException {
        URL url = new URL("https://maps.googleapis.com/maps/api/distancematrix/xml?&mode=" + mod
                + "&units=metric&origins=" + lat1 + ',' + lng1
                + "&destinations=" + lat2 + ',' + lng2
                + "&language=ro&key=AIzaSyCaYb2IUUm0taK3WTb1Whhuvb5ovoA59HU");
        //make connection
        URLConnection urlc = url.openConnection();
        //get result
        BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
        //creare fisier xml
        PrintWriter writer = new PrintWriter("distance.xml", "UTF-8");
        String l = null;
        while ((l = br.readLine()) != null) {
            writer.println(l);
        }
        br.close();
        writer.close();
    }

    public static String getDistance(String c) {

        try {
            File inputFile = new File(c);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("distance");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    return eElement.getElementsByTagName("text").item(0).getTextContent();
                }
            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
        return null;
    }

    public static String getTime(String c) {

        try {
            File inputFile = new File(c);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("duration");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    return eElement.getElementsByTagName("text").item(0).getTextContent();
                }
            }
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
        return null;
    }

    public static void callRoute(String lat1, String lng1, String lat2, String lng2, String mod) throws MalformedURLException, FileNotFoundException, UnsupportedEncodingException, IOException {
        URL url = new URL("https://maps.googleapis.com/maps/api/directions/xml?&mode=" + mod
                + "&origin=" + lat1 + ',' + lng1
                + "&destination=" + lat2 + ',' + lng2
                + "&language=ro&key=AIzaSyDPRTGN-kwLIf85qT5pWasyEMTw3ucvGPs");
        //make connection
        URLConnection urlc = url.openConnection();
        //get result
        BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
        //creare fisier xml
        PrintWriter writer = new PrintWriter("route.xml", "UTF-8");
        String l = null;
        while ((l = br.readLine()) != null) {
            writer.println(l);
        }
        br.close();
        writer.close();
    }

    public static List<String> getSteps(String c) {

        List<String> list = new ArrayList<String>();
        String aj;
        int i = 1;
        try {
            File inputFile = new File(c);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("step");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    //System.out.print(' ');
                    aj = eElement.getElementsByTagName("html_instructions").item(0).getTextContent().replace("<b>", "").replace("</b>", "").replace("</div>", "").replace("<div style=\"font-size:0.9em\">", "");
                    list.add(aj);
                }
            }
            return list;
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }
        return list;
    }

    /*String lat1, lat2, lng1, lng2;
        callPascani();
        lat1 = getLat("pascani.xml");
        lng1 = getLng("pascani.xml");
        callIasi();
        lat2 = getLat("iasi.xml");
        lng2 = getLng("iasi.xml");
        System.out.println("Orasul de plecare: Pascani\n Latitudine: " + lat1 + "\n Longitudine: " + lng1 + "\nOrasul de destinatie: Iasi\n Latitudine: " + lat2 + "\n Longitudine: " + lng2);
        callDistance(lat1, lng1, lat2, lng2, "driving");
        System.out.println("Distante este de " + getDistance("distance.xml"));
        System.out.println("Timpul estimat este de " + getTime("distance.xml"));
        callRoute(lat1, lng1, lat2, lng2, "driving");
        System.out.println("\nPentru a ajunge la destinati urmati urmatorii pasi:");
        getSteps("route.xml");*/
    public static List<String> cost(String... orase) throws IOException, ParserConfigurationException {
        List<String> list = new ArrayList<String>();
        for (String arg : orase) {
            callApi(arg);
        }
        String lat1, lat2, lng1, lng2;
        String aux, auxiliar[];
        float[][] costDrumuri = new float[orase.length][orase.length];
        for (int i = 0; i < orase.length - 1; i++) {
            for (int j = i + 1; j < orase.length; j++) {
                lat1 = getLat(orase[i] + ".xml");
                lng1 = getLng(orase[i] + ".xml");
                lat2 = getLat(orase[j] + ".xml");
                lng2 = getLng(orase[j] + ".xml");
                callDistance(lat1, lng1, lat2, lng2, "driving");
                aux = getDistance("distance.xml");

                auxiliar = aux.split(" ");
                aux = auxiliar[0];
                aux = aux.replace(',', '.');
                costDrumuri[i][j] = Float.parseFloat(aux);
                costDrumuri[j][i] = Float.parseFloat(aux);
            }
        }
        int[] vizitat = new int[orase.length];
        int[] drum = new int[orase.length + 1];
        drum[0] = 0;
        vizitat[0] = 1;
        int curent = 0, auxil = 0;
        int x = 1, urmator;
        float min;
        while (x < orase.length) {
            min = 10000;
            for (int i = 0; i < orase.length; i++) {
                if (curent != i && vizitat[i] == 0) {
                    if (costDrumuri[curent][i] < min) {
                        min = costDrumuri[curent][i];
                        auxil = i;
                    }
                }
            }
            curent = auxil;
            vizitat[curent] = 1;
            drum[x] = curent;
            x++;

        }
        for (int i = 0; i <= orase.length; i++) {
            list.add(orase[drum[i]]);
        }
        float costuri=0;
        for (int i = 1; i <= orase.length; i++) {
            costuri = costuri + costDrumuri[drum[i-1]][drum[i]];
        }
        list.add(Float.toString(costuri));
        return list;
    }

    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
         List<String> list = new ArrayList<String>();
         list = cost("iasi", "pascani");
        /*callApi("iasi");
        callApi("pascani");
        String lat1, lat2, lng1, lng2;
        lat1 = getLat("iasi.xml");
        lng1 = getLng("iasi.xml");
        lat2 = getLat("pascani.xml");
        lng2 = getLng("pascani.xml");
        callDistance(lat1, lng1, lat2, lng2, "driving");
        System.out.println(getDistance("distance.xml"));
        callRoute(lat1, lng1, lat2, lng2, "driving");
        List<String> list = new ArrayList<String>();
        list = getSteps("route.xml");*/
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}
