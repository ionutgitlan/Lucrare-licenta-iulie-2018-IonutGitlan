/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package popularebazadate;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Int;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.nio.charset.StandardCharsets.UTF_8;
import org.w3c.dom.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author ionut
 */
public class PopulareBazaDate {

    public static List<List> getRoute(String o, String d) throws SQLException {
        List<List> list = new ArrayList<List>();
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:student@//localhost:1521/xe", "student", "STUDENT");
        Statement stmt = con.createStatement();
        String sql = "SELECT o.Numar_tren as \"1\", o.Oras as \"2\", o1.Oras as \"3\" , o.Ora_plecare as \"4\" , o1.Ora_sosire as \"5\" FROM Orase o "
                + "                JOIN Orase o1 "
                + "                ON o.Numar_tren = o1.Numar_tren "
                + "                AND o.Oras= '" + o
                + "'                AND o1.Oras = '" + d
                + "'                AND  "
                + "                ( (o1.Ora_Sosire = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340) AND o.Secunde_parcurse<o1.Secunde_parcurse)"
                + "                  OR\n"
                + "                  (o1.Ora_plecare = mod(o.Ora_plecare+(o1.Secunde_parcurse-o.Secunde_parcurse),86340) AND o.Secunde_parcurse<o1.Secunde_parcurse)"
                + "                ) order by o1.Ora_sosire";
        ResultSet rs = stmt.executeQuery(sql);
        int[] rezultat = new int[3];
        while (rs.next()) {
            List<String> element = new ArrayList<String>();
            element.add(rs.getString("1"));
            //System.out.print("Nr: " + rs.getString("1"));
            element.add(getTrainTipe(rs.getString("1")));
            //System.out.print(" Tip: " + getTrainTipe(rs.getString("1")));
            element.add(rs.getString("2"));
            //System.out.print(" Origine: " + rs.getString("2"));
            element.add(rs.getString("3"));
            //System.out.print(" Destinatie: " + rs.getString("3"));
            rezultat = getTime(rs.getInt("4"));
            String ora, min, sec;
            ora = rezultat[0] + "";
            min = rezultat[1] + "";
            sec = rezultat[2] + "";
            if (rezultat[0] < 10) {
                ora = "0" + ora;
            }
            if (rezultat[1] < 10) {
                min = "0" + min;
            }
            if (rezultat[2] < 10) {
                sec = "0" + sec;
            }
            element.add(ora + ":" + min + ":" + sec);
            //System.out.print(" Ora plecare: " + rezultat[0] + ":" + rezultat[1] + ":" +rezultat[2]);
            rezultat = getTime(rs.getInt("5"));
            ora = rezultat[0] + "";
            min = rezultat[1] + "";
            sec = rezultat[2] + "";
            if (rezultat[0] < 10) {
                ora = "0" + ora;
            }
            if (rezultat[1] < 10) {
                min = "0" + min;
            }
            if (rezultat[2] < 10) {
                sec = "0" + sec;
            }
            element.add(ora + ":" + min + ":" + sec);
            list.add(element);
        }
        rs.close();
        return list;
    }

    public static int checkCity(String o) throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:student@//localhost:1521/xe", "student", "STUDENT");
        Statement stmt = con.createStatement();
        String sql = "SELECT * FROM Orase where oras = '" + o
                + "'                ";
        ResultSet rs = stmt.executeQuery(sql);
        int ok = 0;
        while (rs.next()) {
            ok = 1;
        }
        rs.close();
        if (ok == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public static String getTrainTipe(String o) throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:student@//localhost:1521/xe", "student", "STUDENT");
        Statement stmt = con.createStatement();
        String sql = "select * from Tren where Numar_tren= '" + o + "'";
        ResultSet rs = stmt.executeQuery(sql);
        String nr = new String();
        while (rs.next()) {
            nr = rs.getNString(2);
        }
        rs.close();
        return nr;
    }

    public static int[] getTime(int o) throws SQLException {
        int timp = o;
        int ora, minute, secunde;
        ora = timp / 3600;
        minute = (int) Math.round((((float) timp / 3600.0000000000000000F) - timp / 3600) * 60);
        secunde = (int) Math.round(((((float) timp / 3600.0000000000000000F) - timp / 3600) * 60 - minute) * 60);
        int[] rezultat = new int[3];
        rezultat[0] = ora;
        rezultat[1] = minute;
        rezultat[2] = secunde;
        return rezultat;
    }

    public static List<List> getBus(String o, String d) throws SQLException {
        List<List> list = new ArrayList<List>();
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:student@//localhost:1521/xe", "student", "STUDENT");
        Statement stmt = con.createStatement();
        String sql = "SELECT unique t1.Statie as \"1\", t2.Statie as \"2\", t1.Numar_tramvai as \"3\" FROM Trasee t1 "
                + "                JOIN Trasee t2 "
                + "                ON t1.Numar_tramvai = t2.Numar_tramvai "
                + "                Where t1.Statie= '" + o
                + "'                AND t2.Statie = '" + d
                + "'                AND t1.Oprire < t2.Oprire  ";
        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next()) {
            List<String> element = new ArrayList<String>();
            element.add(rs.getString("3"));
            //System.out.print("Nr: " + rs.getString("1"));
            if (rs.getString("3").equals("1") || rs.getString("3").equals("3") || rs.getString("3").equals("6") || rs.getString("3").equals("7") || rs.getString("3").equals("8") || rs.getString("3").equals("9") || rs.getString("3").equals("11") || rs.getString("3").equals("13")) {
                element.add("Tramvai");
            } else {
                element.add("Autobuz");
            }
            element.add(rs.getString("1"));
            //System.out.print(" Origine: " + rs.getString("2"));
            element.add(rs.getString("2"));
            //System.out.print(" Destinatie: " + rs.getString("3"));
            list.add(element);
        }
        rs.close();
        return list;
    }

    public static void main(String[] args) throws SQLException, UnsupportedEncodingException {
       /* try {
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:student@//localhost:1521/xe", "student", "STUDENT");
            Statement stmt = con.createStatement();
            File inputFile = new File("mers-trensntfc2017-2018.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("Tren");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                int delta = 0, old = 0;
                Node nNode = nList.item(temp);
                Element eElement = (Element) nNode;
                System.out.println(eElement.getAttribute("Numar"));
                String sql = "insert into Tren values ("
                        + "'" + eElement.getAttribute("Numar") + "'" + ", "
                        + "'" + eElement.getAttribute("CategorieTren") + "'" + ")";
                stmt.executeUpdate(sql);
                Node nfiu = nList.item(temp);
                Element efiu = (Element) nfiu;
                NodeList fiu = efiu.getElementsByTagName("ElementTrasa");
                for (int trase = 0; trase < fiu.getLength(); trase++) {
                    Node x = fiu.item(trase);
                    Element ex = (Element) x;
                    if (trase >= 1) {
                        if (Integer.parseInt(ex.getAttribute("OraP")) < delta) {
                            delta = delta + (86340 - old);
                            delta = delta + Integer.parseInt(ex.getAttribute("OraP"));
                        } else {
                            delta = delta + (Integer.parseInt(ex.getAttribute("OraP")) - old);
                        }
                    }
                    old = Integer.parseInt(ex.getAttribute("OraP"));
                    if (trase == 0) {
                        System.out.println(ex.getAttribute("DenStaOrigine") + ' ' + "90000" + ' ' + ex.getAttribute("OraP") + ' ' + delta + ' ' + ex.getAttribute("TipOprire").toString());
                        sql = "insert into Orase values ("
                                + "'" + ex.getAttribute("DenStaOrigine") + "'" + ", "
                                + "'" + eElement.getAttribute("Numar") + "'" + ", "
                                + "90000" + ", "
                                + ex.getAttribute("OraP") + ", "
                                + delta + ", "
                                + "'" + ex.getAttribute("TipOprire") + "'" + ")";
                        //System.out.println(sql);
                        stmt.executeUpdate(sql);
                    } else if (trase == fiu.getLength() - 1) {
                        System.out.println(ex.getAttribute("DenStaOrigine") + ' ' + ex.getAttribute("OraS") + ' ' + "90001" + ' ' + delta + ' ' + ex.getAttribute("TipOprire").toString());
                        sql = "insert into Orase values ("
                                + "'" + ex.getAttribute("DenStaOrigine") + "'" + ", "
                                + "'" + eElement.getAttribute("Numar") + "'" + ", "
                                + ex.getAttribute("OraS") + ", "
                                + "90001" + ", "
                                + delta + ", "
                                + "'" + ex.getAttribute("TipOprire") + "'" + ")";
                        //System.out.println(sql);
                        stmt.executeUpdate(sql);
                    } else {
                        Node xOld = fiu.item(trase - 1);
                        Element exOld = (Element) xOld;
                        System.out.println(ex.getAttribute("DenStaOrigine") + ' ' + exOld.getAttribute("OraS") + ' ' + ex.getAttribute("OraP") + ' ' + delta + ' ' + ex.getAttribute("TipOprire").toString());
                        sql = "insert into Orase values ("
                                + "'" + ex.getAttribute("DenStaOrigine") + "'" + ", "
                                + "'" + eElement.getAttribute("Numar") + "'" + ", "
                                + exOld.getAttribute("OraS") + ", "
                                + ex.getAttribute("OraP") + ", "
                                + delta + ", "
                                + "'" + ex.getAttribute("TipOprire") + "')";
                        //System.out.println(sql);
                        stmt.executeUpdate(sql);
                    }
                }
                con.commit();
            }
            con.close();
        } catch (IOException | ParserConfigurationException | DOMException | SAXException e) {
        }*/
 List<List> list = new ArrayList<List>();
        list = getRoute("Cluj Napoca", "Pașcani");
        for (int i = 0; i < list.size(); i++)
            for (int j = 0; j <list.get(i).size(); j++)
                System.out.println((list.get(i)).get(j));
        //System.out.print(checkCity("Cluj Napoca"));
        //System.out.print(getTrainTipe("1832"));
        /*int[] rezultat=new int[3];
        rezultat=getTime(81000);
        System.out.println(rezultat[0]);
        System.out.println(rezultat[1]);
        System.out.println(rezultat[2]);*/
        /*List<List> list = new ArrayList<List>();
        list = getBus("Universitate", "Triumf");
        for (int i = 0; i < list.size(); i++) {
            for (int j = 0; j < list.get(i).size(); j++) {
                System.out.println((list.get(i)).get(j));
            }
        }*/
    }

}
